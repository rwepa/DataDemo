# chorddiag 0.1.3

* Added a `NEWS.md` file to track changes to the package.
* Finally upgraded d3 to version 4, v4.13.0 to be specific.
* Upgrade d3-tip to version 0.81.
* Removed some obsolete external data reducing the package size considerably.
