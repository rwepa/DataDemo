# System   : Taiwan Stock App with shiny
# Date     : May 19, 2022
# Author   : Ming-Chang Lee
# Email    : alan9956@gmail.com
# RWEPA    : http://rwepa.blogspot.tw/
# GitHub   : https://github.com/rwepa
# Encoding : UTF-8

# Packges

Package     Feature
----------- ------------------------------
shiny	    Web Application Framework for R
shinythemes Themes for Shiny
quantmod    Quantitative Financial Modelling Framework
DT          DataTables JavaScript library

# Functions

1.Plot

2.Summary

3.Table

4.Help

# App:
https://rwepa.shinyapps.io/shinyStockVis/

# R code:
https://github.com/rwepa/DataDemo/blob/master/shinyStockVis.zip
