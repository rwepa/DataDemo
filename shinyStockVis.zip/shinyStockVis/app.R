# System   : Taiwan Stock App with shiny
# Date     : May 19, 2022
# Author   : Ming-Chang Lee
# Email    : alan9956@gmail.com
# RWEPA    : http://rwepa.blogspot.tw/
# GitHub   : https://github.com/rwepa
# Encoding : UTF-8

library(shiny)
library(shinythemes)
library(quantmod)
library(DT)

load("data/stockcode.RData")

stock_id_name <- as.list(paste0(stockcode$Market, 
                                "-",
                                stockcode$Name, 
                                " ",
                                stockcode$Code))

ui <- fluidPage(
  
  titlePanel("RWEPA - Taiwan Stock App-v.22.05.19, alan9956@gmail.com, http://rwepa.blogspot.com/"),
  
  theme = shinythemes::shinytheme("cerulean"),

  sidebarLayout(
    
    # Sidebar panel for inputs ----
    sidebarPanel(
      
      selectInput("select_stock_name",
                  label = "Select stock",
                  choices = stock_id_name,
                  selected = "上市-台積電 2330"),
      
      radioButtons("theme", "Plot theme type:",
                   c("Default" = "black",
                     "White" = "white")),
      
      dateRangeInput("daterange", "Date range:",
                     start  = "2021-01-01",
                     end    = Sys.Date()-1,
                     min    = "2000-01-01",
                     max    = Sys.Date()-1,
                     format = "yyyy/mm/dd",
                     separator = " - "),
      
      radioButtons("plotType", "Plot type:",
                   c("Line" = "line",
                     "Bar" = "bar",
                     "Candlesticks" = "candlesticks"))
      
    ),
    
    # Main panel for displaying outputs ----
    mainPanel(
      tabsetPanel(type = "tabs",
                  tabPanel("Plot", plotOutput("plot")),
                  
                  tabPanel("Summary", verbatimTextOutput("summary")),
                  
                  tabPanel("Table", DT::dataTableOutput("mytable_view")),
                  
                  tabPanel("Help", pre(includeText("data/README.txt")))
      )
    )
  )
)

server <- function(input, output) {
  
  stock <- reactive({
    
    tmp <- input$select_stock_name
    
    if (startsWith(tmp, "上市")) {
      tmpname <- paste0(substr(tmp, nchar(tmp)-3, nchar(tmp)), ".TW")
    } else {
      tmpname <- paste0(substr(tmp, nchar(tmp)-3, nchar(tmp)), ".TWO")
    }
    
    tmpstock <- as.data.frame(getSymbols(tmpname,  
                                         from =input$daterange[1], 
                                         to = input$daterange[2],
                                         env = NULL))
    
    tmpstock <- na.omit(tmpstock)

  })

  # plot the data
  output$plot <- renderPlot({
    # x <- stock()
    chartSeries(stock(), 
                type = input$plotType,
                theme=chartTheme(input$theme))
    
  })
  
  # Generate a summary of the data ----
  output$summary <- renderPrint({
    summary(stock())
  })
  
  # Generate an DT table view of the data ----
  output$mytable_view <- DT::renderDataTable({
    x <- stock()
    datatable(x,
              colnames=c("Open", "High", "Low", "Close", "Volume", "Adjusted"),
              options=list(pageLength=10, searching = FALSE))
  })
  
}

# Run the application 
shinyApp(ui = ui, server = server)
# end
